package com.example.flexbook.model;

public enum Status {
    PENDING, ACCEPTED, BLOCKED, DECLINED
}
