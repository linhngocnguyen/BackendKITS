package com.example.productmicroservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductMicroservicesApplicationTests {

    @Test
    void contextLoads() {
    }

}
